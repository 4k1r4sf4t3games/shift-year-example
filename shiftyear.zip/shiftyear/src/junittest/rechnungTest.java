package junittest;

import org.junit.Test;

public class rechnungTest {

	@Test
	public void testShiftyear() {
	
	
	}

}
